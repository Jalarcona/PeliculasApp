import { Component, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tarjetas',
  templateUrl: './tarjetas.component.html',
  styles: []
})
export class TarjetasComponent {

  @Input() items:any[] = [];


  constructor(private router: Router) { }

  verPelicula( item: any ) {

    let peliculaId;

    if ( item.type === 'artist' ) {
      peliculaId = item.id;
    } else {
      peliculaId = item.artists[0].id;
    }

    this.router.navigate([ '/movie', peliculaId  ]);

  }


}
