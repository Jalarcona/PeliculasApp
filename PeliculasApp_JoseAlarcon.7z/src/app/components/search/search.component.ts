import { Component} from '@angular/core';
import { PeliculasService } from '../../services/peliculas.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styles: []
})
export class SearchComponent {

  constructor(private peliculasService: PeliculasService) { }

  buscar(peli: string) {
    console.log(peli);

    this.peliculasService.getSearch(peli).subscribe( (data: any) => {
            console.log(data); // Aqui tengo dudas
            this.buscar = data; // Aqui tengo dudas
          });
  }
}
