import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { HttpClient, HttpClientJsonpModule} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PeliculasService {

  private apikey: string = "84d5ca3fecea5f84d6a0ee0ad9e3930b"; 
  private urlMoviedb: string = "https://api.themoviedb.org/3";

  constructor(private jsonp: HttpClientJsonpModule, private http: HttpClient) { }

  // Prueba Profe
  // getPopulars() {
  //   let url = `${ this.urlMoviedb }/discover/movie?sort_by=popularity.desc&api_key=${ this.apikey }&language=es`;
  //    return this.http.jsonp(url, 'callback');

  // FILTROS DE LA API
  getPopular()
  {
    let url = `${ this.urlMoviedb }/discover/movie?sort_by=popularity.desc&api_key=${ this.apikey }&language=es`;
    return this.http.jsonp(url, 'callback');
  }
  getKids()
  {
    let url = `${ this.urlMoviedb }/discover/movie?api_key=${ this.apikey }&language=es&sort_by=popularity.desc&certification_country=US&certification.lte=G&include_adult=false&include_video=false&page=1`;
    return this.http.jsonp(url, 'callback');  
  }
  getTeatro()
  {
    let date: Date;
    date = new Date();
    date.setDate(date.getDate() - 30);
    let url = `${ this.urlMoviedb }/discover/movie?primary_release_date.gte=${this.datePipe.transform(date, 'yyyy-MM-dd')}&primary_release_date.lte=${this.datePipe.transform(new Date(), 'yyyy-MM-dd')}&api_key=${ this.apikey }&language=es`;
    return this.http.jsonp(url, 'callback');
  }
  getAnho(anho: string) {
    let url = `${ this.urlMoviedb }/discover/movie?sort_by=popularity.desc&api_key=${ this.apikey }&language=es&year=${ anho }`;
     return this.http.jsonp(url, 'callback');
  }
  getSearch(peli: string) {
    let url = `${ this.urlMoviedb }/search/movie?&api_key=${ this.apikey }&query=${ peli }&page=1&language=es`;
     return this.http.jsonp(url, 'callback');
  }
  getMovie(id: number) {
    let url = `${ this.urlMoviedb }/movie/${ id }?&api_key=${ this.apikey }&language=es`;
     return this.http.jsonp(url, 'callback');
  }
}
